﻿/*6. How many book copies have a price that is greater than $20 and less than $25 ?*/

Select COUNT(*)
From copy
where price>20 AND price<25;