/*******************************************
 *
 *  Get availability function
 *
 *******************************************/
CREATE OR REPLACE FUNCTION get_availability(v_pid INTEGER)
RETURNS INTEGER AS 
$func$
DECLARE
  -- RETURNS number of products available
  num INTEGER;
BEGIN
  --count number of products in the product supplier table
  SELECT SUM(qty) INTO num
  FROM Product_Supplier
  WHERE pid = v_pid;

  --check unshipped orders?
  RETURN num;
END;
$func$ LANGUAGE plpgsql;

---------------------------
--Sample calling function--
---------------------------
SELECT * FROM Product_Supplier;
SELECT get_availability(1);
SELECT * FROM Product_Supplier;
