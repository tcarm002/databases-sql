DROP TABLE IF EXISTS Credit_Cards CASCADE;
DROP SEQUENCE IF EXISTS cc_id_seq CASCADE;
CREATE SEQUENCE cc_id_seq;

CREATE TABLE  Credit_Cards (
  cc_id INTEGER PRIMARY KEY DEFAULT  nextval('cc_id_seq'),
  cc_co VARCHAR(45) NOT NULL,
  exp_y INTEGER NOT NULL,
  exp_m INTEGER NOT NULL,
  num VARCHAR(16) NOT NULL,
  defaultCC BOOLEAN NOT NULL,
  aid INTEGER NOT NULL,
  customerID INTEGER REFERENCES Customer (customerID)
);

/*******************************************
 *
 *  Set preferred payment method function
 *
 *******************************************/
CREATE OR REPLACE FUNCTION set_preferred_payment_method(v_customerId INTEGER,
  v_cc_id INTEGER )
RETURNS TEXT AS 
$func$
DECLARE
-- RETURNS message indicating successful change
  msg TEXT := 'Default payment method could not be changed.';
  updated BOOL = False;
  v_oldCC INTEGER;
BEGIN
  --Checks first if this is already the preferred payment method.
  IF EXISTS(SELECT * 
            FROM Credit_Cards
            WHERE customerId = v_customerId
            AND cc_id = v_cc_id
            AND defaultCC = '1') 
  THEN
            msg := 'This is already the preferred payment method. No action taken.' ;
            RETURN msg;
  END IF;

  --Check if customer already has a preferred payment method, if so, unset.
  IF EXISTS(SELECT *
            FROM Credit_Cards 
            WHERE customerId = v_customerId 
            AND defaultCC = '1')
  THEN
            SELECT cc_id INTO v_oldCC
            FROM Credit_Cards 
            WHERE customerId = v_customerId 
            AND defaultCC = '1';
            SELECT update_creditcard(v_oldCC,NULL,NULL,NULL,NULL,'0');
            RAISE NOTICE 'Old default payment method % unset', v_oldCC; 
  END IF;

  --Then set given ccid as new preferred payment method.
  SELECT update_creditcard(v_cc_id,NULL,NULL,NULL,NULL,'1') INTO updated;
    IF updated THEN
      msg := 'New preferred payment method set.';
    END IF;
RETURN msg;
END;
$func$ LANGUAGE plpgsql;

---------------------------
--Sample calling function--
---------------------------
SELECT * FROM Addresses
SELECT * FROM Customer_Addresses;
SELECT set_preferred_shipping_address(1,1);
SELECT * FROM Customer_Addresses;
