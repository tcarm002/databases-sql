/*******************************************
 *
 *  Get Products By Category function
 *
 *******************************************/
CREATE OR REPLACE FUNCTION get_products_by_category(v_categoryId INTEGER)
RETURNS TABLE (pid INTEGER,name VARCHAR(45)) AS 
$func$
BEGIN
  RETURN QUERY SELECT Products.pid,Products.name 
  FROM Products 
  WHERE Products.categoryId = v_categoryId;

END;
$func$ LANGUAGE plpgsql;


/*******************************************
 *
 *  TEST
 *
 *******************************************/

 select get_products_by_category(2);